package com.aali.attendant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * AALI Call Attendant.
 *
 * Watches the telephony state while the guard is ON:
 *  RINGING  -> wait the user delay -> answer via TelecomManager (ANSWER_PHONE_CALLS)
 *  OFFHOOK  -> (only if AALI answered) speakerphone on -> speak the user message via TTS
 *              -> optional auto hang-up after N seconds
 *  IDLE     -> restore audio, post "attended" notification
 */
class CallWatchService : Service() {

    companion object {
        private const val TAG = "AALI"
        const val CHANNEL_GUARD = "aali_guard"
        const val CHANNEL_EVENTS = "aali_events"
        private const val NOTIF_GUARD_ID = 1
        private const val NOTIF_EVENT_ID = 2
        const val DEFAULT_MESSAGE =
            "Hello, you are talking with AALI, Ali's personal assistant. " +
                "Ali is not available to take your call right now. " +
                "Please call again a little later. Thank you."
    }

    private val handler = Handler(Looper.getMainLooper())
    private var audio: AudioManager? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var answeredByUs = false
    private var pendingAnswer: Runnable? = null
    private var pendingEnd: Runnable? = null
    private var modernCallback: TelephonyCallback? = null

    @Suppress("DEPRECATION")
    private val legacyCallback = object : PhoneStateListener() {
        override fun onCallStateChanged(state: Int, phoneNumber: String?) {
            handleState(state)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.RESULT_SUCCESS
            if (ttsReady) {
                runCatching { tts?.language = Locale.US }
            }
        }
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val notification = buildGuardNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIF_GUARD_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
                )
            } else {
                startForeground(NOTIF_GUARD_ID, notification)
            }
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            stopSelf()
            return START_NOT_STICKY
        }
        registerCallWatcher()
        return START_STICKY
    }

    override fun onDestroy() {
        cancelTimers()
        unregisterCallWatcher()
        restoreAudio()
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        tts = null
        super.onDestroy()
    }

    private fun hasPermission(permission: String): Boolean =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun registerCallWatcher() {
        if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            stopSelf()
            return
        }
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Instantiate inside the branch so the class is never loaded on old APIs.
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handleState(state)
                    }
                }
                modernCallback = cb
                tm.registerTelephonyCallback(mainExecutor, cb)
            } else {
                @Suppress("DEPRECATION")
                tm.listen(legacyCallback, PhoneStateListener.LISTEN_CALL_STATE)
            }
        } catch (e: Exception) {
            Log.e(TAG, "register call watcher failed", e)
        }
    }

    private fun unregisterCallWatcher() {
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                modernCallback?.let { tm.unregisterTelephonyCallback(it) }
                modernCallback = null
            } else {
                @Suppress("DEPRECATION")
                tm.listen(legacyCallback, PhoneStateListener.LISTEN_NONE)
            }
        } catch (_: Exception) {
        }
    }

    private fun handleState(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> onRinging()
            TelephonyManager.CALL_STATE_OFFHOOK -> onOffhook()
            TelephonyManager.CALL_STATE_IDLE -> onIdle()
        }
    }

    private fun onRinging() {
        cancelTimers()
        answeredByUs = false
        if (!Prefs.enabled(this)) return
        if (!hasPermission(Manifest.permission.ANSWER_PHONE_CALLS)) return
        val delayMs = Prefs.delaySeconds(this) * 1000L
        val task = Runnable { tryAnswer() }
        pendingAnswer = task
        handler.postDelayed(task, delayMs)
    }

    private fun tryAnswer() {
        pendingAnswer = null
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            @Suppress("DEPRECATION")
            if (tm.callState != TelephonyManager.CALL_STATE_RINGING) return
            val telecom = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            @Suppress("DEPRECATION")
            telecom.acceptRingingCall()
            answeredByUs = true
        } catch (e: Exception) {
            Log.e(TAG, "answer failed", e)
            answeredByUs = false
        }
    }

    private fun onOffhook() {
        pendingAnswer?.let { handler.removeCallbacks(it) }
        pendingAnswer = null
        if (!answeredByUs) return
        handler.postDelayed({ speakToCaller() }, 1200)
    }

    private fun speakToCaller() {
        val am = audio ?: return
        try {
            am.mode = AudioManager.MODE_IN_CALL
            if (Prefs.speaker(this)) {
                am.isSpeakerphoneOn = true
            }
        } catch (_: Exception) {
        }
        handler.postDelayed({
            if (!ttsReady) return@postDelayed
            val msg = Prefs.message(this).ifBlank { DEFAULT_MESSAGE }
            runCatching { tts?.setSpeechRate(0.95f) }
            tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "aali-call-msg")
            if (Prefs.autoEnd(this)) {
                val endMs = Prefs.endAfterSeconds(this) * 1000L
                val task = Runnable { hangUp() }
                pendingEnd = task
                handler.postDelayed(task, endMs)
            }
        }, 800)
    }

    private fun hangUp() {
        pendingEnd = null
        try {
            val telecom = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            @Suppress("DEPRECATION")
            telecom.endCall()
        } catch (e: Exception) {
            Log.e(TAG, "end call failed", e)
        }
    }

    private fun onIdle() {
        cancelTimers()
        if (answeredByUs) {
            event(getString(R.string.event_attended))
        }
        answeredByUs = false
        restoreAudio()
        runCatching { tts?.stop() }
    }

    private fun restoreAudio() {
        try {
            audio?.mode = AudioManager.MODE_NORMAL
            audio?.isSpeakerphoneOn = false
        } catch (_: Exception) {
        }
    }

    private fun cancelTimers() {
        pendingAnswer?.let { handler.removeCallbacks(it) }
        pendingEnd?.let { handler.removeCallbacks(it) }
        pendingAnswer = null
        pendingEnd = null
    }

    private fun event(text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        ) {
            return
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL_EVENTS)
            .setSmallIcon(R.drawable.ic_aali)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_EVENT_ID, n)
    }

    private fun buildGuardNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_GUARD)
            .setSmallIcon(R.drawable.ic_aali)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.guard_notification))
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    private fun createChannels() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_GUARD, "Guard status", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_EVENTS, "Call events", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }
}
