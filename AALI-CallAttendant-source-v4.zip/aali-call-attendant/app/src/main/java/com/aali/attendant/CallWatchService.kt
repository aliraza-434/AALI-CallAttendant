package com.aali.attendant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.CallLog
import android.speech.tts.TextToSpeech
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.SmsManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * AALI Call Attendant.
 *
 * Watches the telephony state while the guard is ON:
 *  RINGING  -> wait the user delay -> answer via TelecomManager (ANSWER_PHONE_CALLS)
 *  OFFHOOK  -> (only if AALI answered) speakerphone on -> speak the user message via TTS
 *              -> optional auto hang-up after N seconds
 *  IDLE     -> restore audio, post "attended" notification
 */
class CallWatchService : Service() {

    companion object {
        private const val TAG = "AALI"
        const val CHANNEL_GUARD = "aali_guard"
        const val CHANNEL_EVENTS = "aali_events"
        private const val NOTIF_GUARD_ID = 1
        private const val NOTIF_EVENT_ID = 2
        const val DEFAULT_MESSAGE =
            "Hello, you are talking with AALI, Ali's personal assistant. " +
                "Ali is not available to take your call right now. " +
                "Please call again a little later. Thank you."
        const val DEFAULT_SMS =
            "Sorry, Ali can't take your call right now. He will call you back later. — AALI (auto reply)"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var audio: AudioManager? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var answeredByUs = false
    private var prevCallVolume = -1
    private var pendingAnswer: Runnable? = null
    private var pendingEnd: Runnable? = null
    private var modernCallback: TelephonyCallback? = null

    @Suppress("DEPRECATION")
    private val legacyCallback = object : PhoneStateListener() {
        override fun onCallStateChanged(state: Int, phoneNumber: String?) {
            handleState(state)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        DebugLog.add(this, "Service created")
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                runCatching { tts?.setLanguage(Locale.US) }
            }
        }
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!startAsForeground()) {
            DebugLog.add(this, "ERROR: could not start foreground service")
            stopSelf()
            return START_NOT_STICKY
        }
        registerCallWatcher()
        DebugLog.add(this, "Guard started (v1.2)")
        return START_STICKY
    }

    /**
     * Android 14 only allows the phoneCall FGS type for apps that also hold
     * MANAGE_OWN_CALLS (or are the default dialer). We now declare that
     * permission, but strict OEM ROMs still block it — so we degrade
     * gracefully: phoneCall -> specialUse -> plain startForeground.
     */
    private fun startAsForeground(): Boolean {
        val notification = buildGuardNotification()
        val attempts = mutableListOf<Pair<String, () -> Unit>>()
        attempts.add(
            "phoneCall" to {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIF_GUARD_ID, notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
                    )
                } else {
                    startForeground(NOTIF_GUARD_ID, notification)
                }
            }
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            attempts.add(
                "specialUse" to {
                    startForeground(
                        NOTIF_GUARD_ID, notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                }
            )
        }
        attempts.add("plain" to { startForeground(NOTIF_GUARD_ID, notification) })

        for ((name, attempt) in attempts) {
            try {
                attempt()
                DebugLog.add(this, "Foreground service OK ($name type)")
                return true
            } catch (e: Exception) {
                Log.e(TAG, "startForeground($name) failed", e)
                DebugLog.add(this, "FGS $name failed: ${e.message?.take(200) ?: "error"}")
            }
        }
        return false
    }

    override fun onDestroy() {
        DebugLog.add(this, "Service destroyed")
        cancelTimers()
        unregisterCallWatcher()
        restoreAudio()
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        tts = null
        super.onDestroy()
    }

    private fun hasPermission(permission: String): Boolean =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun registerCallWatcher() {
        if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            DebugLog.add(this, "ERROR: READ_PHONE_STATE missing — guard stopped")
            stopSelf()
            return
        }
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Instantiate inside the branch so the class is never loaded on old APIs.
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handleState(state)
                    }
                }
                modernCallback = cb
                tm.registerTelephonyCallback(mainExecutor, cb)
                DebugLog.add(this, "Watcher registered (TelephonyCallback, API ${Build.VERSION.SDK_INT})")
            } else {
                @Suppress("DEPRECATION")
                tm.listen(legacyCallback, PhoneStateListener.LISTEN_CALL_STATE)
                DebugLog.add(this, "Watcher registered (PhoneStateListener, API ${Build.VERSION.SDK_INT})")
            }
        } catch (e: Exception) {
            Log.e(TAG, "register call watcher failed", e)
            DebugLog.add(this, "ERROR register watcher: ${e.message}")
        }
    }

    private fun unregisterCallWatcher() {
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                modernCallback?.let { tm.unregisterTelephonyCallback(it) }
                modernCallback = null
            } else {
                @Suppress("DEPRECATION")
                tm.listen(legacyCallback, PhoneStateListener.LISTEN_NONE)
            }
        } catch (_: Exception) {
        }
    }

    private fun handleState(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> onRinging()
            TelephonyManager.CALL_STATE_OFFHOOK -> onOffhook()
            TelephonyManager.CALL_STATE_IDLE -> onIdle()
        }
    }

    private fun onRinging() {
        cancelTimers()
        answeredByUs = false
        if (!Prefs.enabled(this)) {
            DebugLog.add(this, "RINGING detected — but guard is OFF")
            return
        }
        if (!hasPermission(Manifest.permission.ANSWER_PHONE_CALLS)) {
            DebugLog.add(this, "ERROR: RINGING but ANSWER_PHONE_CALLS missing")
            return
        }
        val delayMs = Prefs.delaySeconds(this) * 1000L
        if (Prefs.smsMode(this)) {
            DebugLog.add(this, "RINGING — SMS mode: will decline in ${Prefs.delaySeconds(this)}s")
            val task = Runnable { declineAndSms() }
            pendingAnswer = task
            handler.postDelayed(task, delayMs)
            return
        }
        DebugLog.add(this, "RINGING — will answer in ${Prefs.delaySeconds(this)}s")
        val task = Runnable { tryAnswer() }
        pendingAnswer = task
        handler.postDelayed(task, delayMs)
    }

    private fun tryAnswer() {
        pendingAnswer = null
        DebugLog.add(this, "Delay over — answering now…")
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            @Suppress("DEPRECATION")
            if (tm.callState != TelephonyManager.CALL_STATE_RINGING) {
                DebugLog.add(this, "No longer ringing (caller gave up or answered)")
                return
            }
            val telecom = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            @Suppress("DEPRECATION")
            telecom.acceptRingingCall()
            answeredByUs = true
            DebugLog.add(this, "Answer command sent ✓")
        } catch (e: Exception) {
            Log.e(TAG, "answer failed", e)
            DebugLog.add(this, "ANSWER FAILED: ${e.message}")
            answeredByUs = false
        }
    }

    private fun onOffhook() {
        pendingAnswer?.let { handler.removeCallbacks(it) }
        pendingAnswer = null
        if (!answeredByUs) {
            DebugLog.add(this, "Connected — answered manually, AALI stays quiet")
            return
        }
        DebugLog.add(this, "Connected (AALI answered)")
        handler.postDelayed({ speakToCaller() }, 1200)
    }

    private fun speakToCaller() {
        val am = audio ?: return
        try {
            am.mode = AudioManager.MODE_IN_CALL
            if (Prefs.speaker(this)) {
                am.isSpeakerphoneOn = true
            }
            // Put the voice-call stream on max — TTS rides on it so the CALLER
            // hears AALI through the call audio path, not just the room mic.
            prevCallVolume = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
            am.setStreamVolume(
                AudioManager.STREAM_VOICE_CALL,
                am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL),
                0
            )
        } catch (_: Exception) {
        }
        DebugLog.add(this, "Speaker: ${if (Prefs.speaker(this)) "on" else "off"} + call volume max")
        handler.postDelayed({
            if (!ttsReady) {
                DebugLog.add(this, "ERROR: TTS not ready yet")
                return@postDelayed
            }
            val msg = Prefs.message(this).ifBlank { DEFAULT_MESSAGE }
            runCatching { tts?.setSpeechRate(0.95f) }
            val params = Bundle().apply {
                putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_VOICE_CALL)
            }
            tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, params, "aali-call-msg")
            DebugLog.add(this, "Speaking on the call line (caller should hear)…")
            if (Prefs.autoEnd(this)) {
                val endMs = Prefs.endAfterSeconds(this) * 1000L
                val task = Runnable { hangUp() }
                pendingEnd = task
                handler.postDelayed(task, endMs)
            }
        }, 800)
    }

    private fun declineAndSms() {
        pendingAnswer = null
        DebugLog.add(this, "Delay over — declining call + sending SMS…")
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            @Suppress("DEPRECATION")
            if (tm.callState != TelephonyManager.CALL_STATE_RINGING) {
                DebugLog.add(this, "No longer ringing (caller gave up or answered)")
                return
            }
            val telecom = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            @Suppress("DEPRECATION")
            telecom.endCall()
            DebugLog.add(this, "Call declined ✓")
            // Call log writes the rejected entry a moment later.
            handler.postDelayed({ sendSmsToCaller() }, 2000)
        } catch (e: Exception) {
            Log.e(TAG, "decline failed", e)
            DebugLog.add(this, "DECLINE FAILED: ${e.message?.take(200) ?: "error"}")
        }
    }

    private fun sendSmsToCaller() {
        if (!hasPermission(Manifest.permission.SEND_SMS)) {
            DebugLog.add(this, "ERROR: SEND_SMS permission missing")
            return
        }
        val number = findLastCallerNumber()
        if (number.isNullOrBlank()) {
            DebugLog.add(this, "ERROR: caller number not found in call log")
            return
        }
        try {
            val sm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            val text = Prefs.smsText(this).ifBlank { DEFAULT_SMS }
            val parts = sm.divideMessage(text)
            if (parts.size <= 1) {
                sm.sendTextMessage(number, null, text, null, null)
            } else {
                sm.sendMultipartTextMessage(number, null, parts, null, null)
            }
            DebugLog.add(this, "SMS sent to $number ✓")
            event(getString(R.string.sms_sent_event, number))
        } catch (e: Exception) {
            Log.e(TAG, "sms failed", e)
            DebugLog.add(this, "SMS FAILED: ${e.message?.take(120) ?: "error"}")
        }
    }

    private fun findLastCallerNumber(): String? {
        if (!hasPermission(Manifest.permission.READ_CALL_LOG)) return null
        return try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER),
                "${CallLog.Calls.TYPE} IN (${CallLog.Calls.INCOMING_TYPE}, " +
                    "${CallLog.Calls.MISSED_TYPE}, ${CallLog.Calls.REJECTED_TYPE})",
                null,
                "${CallLog.Calls._ID} DESC"
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (_: Exception) {
            null
        }
    }

    private fun hangUp() {
        pendingEnd = null
        DebugLog.add(this, "Auto hang-up — ending call")
        try {
            val telecom = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            @Suppress("DEPRECATION")
            telecom.endCall()
        } catch (e: Exception) {
            Log.e(TAG, "end call failed", e)
        }
    }

    private fun onIdle() {
        cancelTimers()
        DebugLog.add(this, "Call ended")
        if (answeredByUs) {
            event(getString(R.string.event_attended))
        }
        answeredByUs = false
        restoreAudio()
        runCatching { tts?.stop() }
    }

    private fun restoreAudio() {
        try {
            if (prevCallVolume >= 0) {
                audio?.setStreamVolume(AudioManager.STREAM_VOICE_CALL, prevCallVolume, 0)
                prevCallVolume = -1
            }
            audio?.mode = AudioManager.MODE_NORMAL
            audio?.isSpeakerphoneOn = false
        } catch (_: Exception) {
        }
    }

    private fun cancelTimers() {
        pendingAnswer?.let { handler.removeCallbacks(it) }
        pendingEnd?.let { handler.removeCallbacks(it) }
        pendingAnswer = null
        pendingEnd = null
    }

    private fun event(text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        ) {
            return
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL_EVENTS)
            .setSmallIcon(R.drawable.ic_aali)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_EVENT_ID, n)
    }

    private fun buildGuardNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_GUARD)
            .setSmallIcon(R.drawable.ic_aali)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.guard_notification))
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    private fun createChannels() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_GUARD, "Guard status", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_EVENTS, "Call events", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }
}
