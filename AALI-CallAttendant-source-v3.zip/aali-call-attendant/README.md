# AALI Call Attendant

A tiny native Android app that lets **AALI answer incoming phone calls for you** on your Pixel 7 (works on other Android 9+ phones too).

It is the native companion to the AALI PWA. The AALI web app itself can never touch phone calls — Android keeps telephony completely out of reach of browsers and PWAs. So this small app does the phone part, **fully offline**.

## What it does

- Watches for incoming calls while its **Call guard** is ON.
- Waits your chosen delay (1–15 s) so you can still grab the call yourself.
- Answers the call automatically (special "answer phone calls" permission).
- Turns on the speakerphone and speaks your editable message out loud — the caller hears AALI's voice (device TTS engine, works offline once an English voice is downloaded).
- Optionally hangs up automatically after your chosen number of seconds (10–60 s).
- Posts a notification when AALI attended a call for you.
- **100% offline**: the app has no internet permission at all.

## What it cannot do (honest limits)

- **AALI cannot hear the caller.** Android only allows the default dialer app to access call audio, so a live conversation on a normal phone call is impossible for any normal app.
- Audio quality: the caller hears your phone's speaker through their mic (answering-machine style), not studio audio.
- It answers **all** incoming calls while the guard is ON (no whitelist in v1).

## Permissions it asks for

| Permission | Why |
| --- | --- |
| Phone state | Detect that a call is ringing |
| Answer phone calls | Answer the call / hang up |
| Notifications | Show "AALI is guarding" + call events |

## Get the APK — route A: GitHub Actions (no Android Studio needed)

**Easiest way — upload just the zip (works from your phone):**

1. Create a free GitHub account (verify your email) and open github.com.
2. Tap the **+** (top right) → **New repository** → name it `aali-call-attendant` → choose **Public** → **Create repository** (leave all checkboxes unticked).
3. On the empty repo page tap **"uploading an existing file"** → select `AALI-CallAttendant-source.zip` (one file, no need to unzip it) → **Commit changes**.
4. Open the **Actions** tab → the **"Build AALI APK"** run starts automatically and unzips everything itself. Wait until it turns green (2–4 minutes).
5. Open the finished run → **Artifacts** → download `AALI-CallAttendant-debug-apk` → extract the zip (Google Files app) → install `app-debug.apk`.

**Alternative — upload the unzipped folder (PC + Chrome):** unzip first, then **Add file → Upload files** and drag the folder's contents in (including the `.github` folder). The workflow detects this and skips the unzip step.

## Route B: Android Studio

Open the unzipped folder in Android Studio (Koala or newer), let Gradle sync, then **Build → Build APK(s)**.

## Install & first run on your Pixel 7

1. Tap the APK → allow **Install unknown apps** for the app you are installing from (Pixel: Settings → Apps → Special app access → Install unknown apps).
2. Open **AALI Call Attendant** → tap **Grant phone permissions** → allow all three.
3. Flip **Call guard** ON. The "AALI is guarding your calls" notification must appear.
4. Tap **Test AALI's voice** — you should hear the message through the speaker.
5. Call yourself from another phone and watch AALI pick it up after the delay.

### Offline voice tip

For fully offline speech: Settings → search "Text-to-speech" → **Google Speech Services** → Language → download **English (United States)**. AALI's call voice then works with no internet at all.

## Tuning

- **Answer delay**: keep 4–8 s so you can still answer yourself in time.
- **Message**: tap the text box and write whatever AALI should say (English works best with the default voice).
- **Hang up automatically**: enable only if you want AALI to end the call itself (e.g. after 20 s).
- If the caller can't hear AALI: keep **Use speakerphone** ON and raise the media volume during a test call.
- Battery: the "guarding" notification is required by Android; on Pixel you can long-press it and turn that channel off without breaking the guard.

## Version

v1.0 — auto-answer + spoken message + optional auto hang-up.

Ideas for v2: missed-call auto SMS reply, number whitelist/blacklist, per-contact messages.
