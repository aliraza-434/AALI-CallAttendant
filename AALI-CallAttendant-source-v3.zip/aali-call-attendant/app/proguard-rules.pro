# AALI Call Attendant keeps default rules; minification is off for debug builds.
