package com.aali.attendant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * Restarts the guard after the phone restarts, so the user does not have to
 * open the app every time the device reboots. Only acts if the guard was ON.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.enabled(context)) {
            DebugLog.add(context, "Phone restarted — guard restarting")
            ContextCompat.startForegroundService(
                context,
                Intent(context, CallWatchService::class.java)
            )
        }
    }
}
