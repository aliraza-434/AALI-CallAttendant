package com.aali.attendant

import android.content.Context

object Prefs {
    private const val FILE = "aali_attendant"

    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    fun delaySeconds(c: Context) = p(c).getInt("delay", 4)
    fun setDelaySeconds(c: Context, v: Int) = p(c).edit().putInt("delay", v).apply()

    fun message(c: Context): String =
        p(c).getString("message", CallWatchService.DEFAULT_MESSAGE) ?: CallWatchService.DEFAULT_MESSAGE

    fun setMessage(c: Context, v: String) = p(c).edit().putString("message", v).apply()

    fun speaker(c: Context) = p(c).getBoolean("speaker", true)
    fun setSpeaker(c: Context, v: Boolean) = p(c).edit().putBoolean("speaker", v).apply()

    fun autoEnd(c: Context) = p(c).getBoolean("auto_end", false)
    fun setAutoEnd(c: Context, v: Boolean) = p(c).edit().putBoolean("auto_end", v).apply()

    fun endAfterSeconds(c: Context) = p(c).getInt("end_after", 30)
    fun setEndAfterSeconds(c: Context, v: Int) = p(c).edit().putInt("end_after", v).apply()
}
