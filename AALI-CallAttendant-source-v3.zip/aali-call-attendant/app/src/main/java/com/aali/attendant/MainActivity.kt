package com.aali.attendant

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingEnable = false
    private var booting = true

    private lateinit var guardSwitch: MaterialSwitch
    private lateinit var speakerSwitch: MaterialSwitch
    private lateinit var endSwitch: MaterialSwitch
    private lateinit var statusText: TextView
    private lateinit var delayLabel: TextView
    private lateinit var endLabel: TextView
    private lateinit var delayBar: SeekBar
    private lateinit var endBar: SeekBar
    private lateinit var msgInput: EditText
    private lateinit var grantButton: MaterialButton
    private lateinit var testVoiceButton: MaterialButton
    private lateinit var batteryButton: MaterialButton
    private lateinit var copyLogButton: MaterialButton
    private lateinit var clearLogButton: MaterialButton
    private lateinit var logText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val logRefresher = object : Runnable {
        override fun run() {
            logText.text = DebugLog.read(this@MainActivity)
            handler.postDelayed(this, 1500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        guardSwitch = findViewById(R.id.guardSwitch)
        speakerSwitch = findViewById(R.id.speakerSwitch)
        endSwitch = findViewById(R.id.endSwitch)
        statusText = findViewById(R.id.statusText)
        delayLabel = findViewById(R.id.delayLabel)
        endLabel = findViewById(R.id.endLabel)
        delayBar = findViewById(R.id.delayBar)
        endBar = findViewById(R.id.endBar)
        msgInput = findViewById(R.id.msgInput)
        grantButton = findViewById(R.id.grantButton)
        testVoiceButton = findViewById(R.id.testVoiceButton)
        batteryButton = findViewById(R.id.batteryButton)
        copyLogButton = findViewById(R.id.copyLogButton)
        clearLogButton = findViewById(R.id.clearLogButton)
        logText = findViewById(R.id.logText)

        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                runCatching { tts?.setLanguage(Locale.US) }
            }
        }

        loadSettings()
        wireControls()
        booting = false
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onStart() {
        super.onStart()
        handler.post(logRefresher)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(logRefresher)
    }

    override fun onDestroy() {
        runCatching { tts?.shutdown() }
        tts = null
        super.onDestroy()
    }

    private fun loadSettings() {
        guardSwitch.isChecked = Prefs.enabled(this)
        speakerSwitch.isChecked = Prefs.speaker(this)
        endSwitch.isChecked = Prefs.autoEnd(this)
        delayBar.max = 14
        delayBar.progress = Prefs.delaySeconds(this) - 1
        endBar.max = 50
        endBar.progress = Prefs.endAfterSeconds(this) - 10
        msgInput.setText(Prefs.message(this))
        updateDelayLabel()
        updateEndLabel()
    }

    private fun wireControls() {
        guardSwitch.setOnCheckedChangeListener { _, on ->
            if (booting) return@setOnCheckedChangeListener
            Prefs.setEnabled(this, on)
            if (on) enableGuard() else disableGuard()
        }

        speakerSwitch.setOnCheckedChangeListener { _, on ->
            Prefs.setSpeaker(this, on)
        }

        endSwitch.setOnCheckedChangeListener { _, on ->
            Prefs.setAutoEnd(this, on)
        }

        delayBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                Prefs.setDelaySeconds(this@MainActivity, value + 1)
                updateDelayLabel()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        endBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                Prefs.setEndAfterSeconds(this@MainActivity, value + 10)
                updateEndLabel()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        msgInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (booting) return
                Prefs.setMessage(this@MainActivity, s?.toString().orEmpty())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        grantButton.setOnClickListener {
            ActivityCompat.requestPermissions(this, neededPerms(), 11)
        }

        batteryButton.setOnClickListener { fixBattery() }

        copyLogButton.setOnClickListener {
            val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cb.setPrimaryClip(ClipData.newPlainText("AALI log", DebugLog.read(this)))
            Toast.makeText(this, R.string.log_copied, Toast.LENGTH_SHORT).show()
        }

        clearLogButton.setOnClickListener {
            DebugLog.clear(this)
            logText.text = DebugLog.read(this)
        }

        testVoiceButton.setOnClickListener {
            DebugLog.add(this, "Test voice tapped")
            testVoice()
        }
    }

    private fun updateDelayLabel() {
        delayLabel.text = getString(R.string.delay_value, Prefs.delaySeconds(this))
    }

    private fun updateEndLabel() {
        endLabel.text = getString(R.string.end_value, Prefs.endAfterSeconds(this))
    }

    private fun neededPerms(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        return list.toTypedArray()
    }

    private fun granted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun allGranted(): Boolean = neededPerms().all { granted(it) }

    private fun enableGuard() {
        if (!allGranted()) {
            pendingEnable = true
            ActivityCompat.requestPermissions(this, neededPerms(), 11)
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, CallWatchService::class.java))
        DebugLog.add(this, "Guard switched ON")
        Toast.makeText(
            this,
            getString(R.string.toast_on, Prefs.delaySeconds(this)),
            Toast.LENGTH_SHORT
        ).show()
        refreshStatus()
    }

    private fun disableGuard() {
        stopService(Intent(this, CallWatchService::class.java))
        Toast.makeText(this, R.string.toast_off, Toast.LENGTH_SHORT).show()
        refreshStatus()
    }

    private fun testVoice() {
        if (!ttsReady) {
            Toast.makeText(this, R.string.toast_tts_starting, Toast.LENGTH_SHORT).show()
            return
        }
        runCatching { tts?.setSpeechRate(0.95f) }
        tts?.speak(Prefs.message(this), TextToSpeech.QUEUE_FLUSH, null, "aali-test")
    }

    private fun isBatteryFree(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun fixBattery() {
        if (isBatteryFree()) {
            Toast.makeText(this, R.string.toast_battery_already, Toast.LENGTH_SHORT).show()
            return
        }
        DebugLog.add(this, "Battery fix requested")
        val opened = runCatching {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }.isSuccess
        if (!opened) {
            runCatching {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    private fun refreshStatus() {
        val phone = granted(Manifest.permission.READ_PHONE_STATE)
        val answer = granted(Manifest.permission.ANSWER_PHONE_CALLS)
        val notif = Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)
        val guard = Prefs.enabled(this)
        statusText.text = getString(
            R.string.status_line,
            if (guard) "ON" else "OFF",
            if (phone) "OK" else "missing",
            if (answer) "OK" else "missing",
            if (notif) "OK" else "missing"
        )
        batteryButton.text =
            if (isBatteryFree()) getString(R.string.battery_ok)
            else getString(R.string.battery_fix)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
        if (!pendingEnable) return
        pendingEnable = false
        if (allGranted()) {
            ContextCompat.startForegroundService(this, Intent(this, CallWatchService::class.java))
            Toast.makeText(this, R.string.toast_on_short, Toast.LENGTH_SHORT).show()
        } else {
            guardSwitch.isChecked = false
            Prefs.setEnabled(this, false)
            Toast.makeText(this, R.string.toast_perms_denied, Toast.LENGTH_LONG).show()
        }
    }
}
