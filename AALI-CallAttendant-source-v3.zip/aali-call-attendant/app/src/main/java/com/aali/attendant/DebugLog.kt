package com.aali.attendant

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tiny persistent debug log (last 40 lines).
 *
 * Every important guard event is timestamped here so that the user can open
 * the app, read the timeline of the last call, and paste it back to the
 * developer — no adb, no logcat needed.
 */
object DebugLog {
    private const val FILE = "aali_debug_log"
    private const val KEY = "entries"
    private const val MAX_LINES = 40

    fun add(context: Context, entry: String) {
        try {
            val ts = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            val line = "$ts  $entry"
            val p = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            val old = p.getString(KEY, "").orEmpty()
            val lines = if (old.isBlank()) mutableListOf(line)
            else ArrayList(old.split("\n")).apply { add(line) }
            while (lines.size > MAX_LINES) lines.removeAt(0)
            p.edit().putString(KEY, lines.joinToString("\n")).apply()
        } catch (_: Exception) {
        }
    }

    fun read(context: Context): String {
        val text = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY, "").orEmpty()
        return text.ifBlank { context.getString(R.string.log_empty) }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply()
    }
}
